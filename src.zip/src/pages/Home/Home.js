import React, { useState } from "react";
import Form from "../Formulario/Form";


  const Home = () => {
    const [search, setSearch] = useState('');
    const [form, setForm] = useState(false);

    return (
      <form onSubmit={ev =>{
        ev.preventDefault();
        setSearch(ev.target.search.value);
        setForm(true)
      }}
      >
          <input type="carrera" name='search' placeholder="Carrera"/>
          <input type="grado"  name='search' placeholder="Grado"/>
          <input type="turno" name='search' placeholder="Turno"/>
          <button type='submit'>Buscar</button>
          <p> Resultados del alumno: {search} </p>
          {form ? <Form/> : null}
          
      </form>
    );
  
  }

export default Home; 